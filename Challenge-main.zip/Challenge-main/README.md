📝 Ton brief 
-------------

Chaque semaine, tu pourras retrouver ici un challenge à compléter.

Ton challenge est le suivant : reconstuire la maquette donnée, **à l'identique** ! 

✅ Tu as à ta disposition :

-   Maquette Figma
-   Code pour commencer + images sur ce repository
-   Les commentaires sur Bonzai pour tes questions
-   Langages / framework / librairies que tu veux...

❌ Il faut que tu fasses attention :

-   Aux détails d'interfaces
-   Aux animations 
-   À la justesse de ton code


📅 Calendrier du challenge
-------------
-   Lundi → Publication de l'exercice
-   Vendredi → Publication de la correction


🪐 Rejoins-nous
-------------
Suis l'avancé des challenges directement sur [Bonzai](https://www.bonzai.lol/challenge_ezis/lp/604/et-si-tu-arretais-de-procrastiner).
